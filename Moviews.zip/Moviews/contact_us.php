<?php
	require_once("templates/header.php");
	require_once("models/Message.php");
	require_once("models/User.php");
	require_once("dao/UserDAO.php");
	
	$userData = $userDao -> verifyToken(true);
	$user = new User();
	
	$access_key = "300857b4-146e-4bc0-af3f-a25f96e6e159";
	$user_fullname = $user -> getFullName($userData);
	$user_email = $userData -> email;
?>

<div id="main-container" class="container-fluid">
	<div class="col-md-12">
		<div class="row" id="auth-row">
			<div class="col-md-4" id="contact-container">
				<h2> Fale conosco </h2>
				<!-- Envio de e-mail da API -->
				<form action="https://api.staticforms.xyz/submit" method="POST">
					<!-- Chave de acesso da API -->
					<input type="hidden" name="accessKey" value="<?= $access_key ?>">
					
					<!-- O assunto do e-mail -->
					<input type="hidden" name="subject" value="Moviews (Fale conosco)">
					
					<!-- Nome do usuário -->
					<input type="hidden" name="$usuário" value="<?= $user_fullname ?>">
					
					<!-- E-mail do usuário -->
					<input type="hidden" name="$">
					<input type="hidden" name="$e-mail" value="<?= $user_email ?>">
					
					<!-- A mensagem que será enviada -->
					<input type="hidden" name="$ ">
					<div class="form-group">
						<label for="message"> Mensagem: </label>
						<textarea class="form-control message" id="message" name="$mensagem" rows="6" cols="33" placeholder="Digite sua mensagem"></textarea>
					</div>
					
					<!-- O tipo de mensagem -->
					<input type="hidden" name="$  ">
					<div class="form-group">
						<label for="type_message"> Minha mensagem é: </label>
						<select class="form-control" id="type_message" name="$observação">
							<option value="A mensagem é um comentário."> um Comentário </option>
							<option value="A mensagem é uma reclamação."> uma Reclamação </option>
							<option value="A mensagem é uma sugestão."> uma Sugestão </option>
							<option value="A mensagem não é um comentário, uma reclamação e nem uma sugestão."> Nenhuma das opções </option>
						</select>
					</div>
					
					<!-- Página que vai acessar -->
					<input type="hidden" name="redirectTo" value="<?=$BASE_URL ?>contact_sucess.php">
					
					<!-- Botão para confirmar -->
					<input type="submit" class="btn card-btn" value="Enviar mensagem">
				</form>
			</div>
		</div>
	</div>
</div>
<?php require_once("templates/footer.php"); ?>